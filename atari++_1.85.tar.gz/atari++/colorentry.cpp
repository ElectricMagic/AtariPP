/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: colorentry.cpp,v 1.2 2015/05/21 18:52:37 thor Exp $
 **
 ** In this module: Color Entry color map definition
 **********************************************************************************/
