/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: licence.hpp,v 1.3 2015/05/21 18:52:40 thor Exp $
 **
 ** In this module: The licence condition string
 **********************************************************************************/

#ifndef LICENCE_HPP
#define LICENCE_HPP

extern const char Licence[];

#endif
