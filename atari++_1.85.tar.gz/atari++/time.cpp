/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: time.cpp,v 1.3 2015/05/21 18:52:43 thor Exp $
 **
 ** In this module: Os abstraction for timing interfaces
 **********************************************************************************/
