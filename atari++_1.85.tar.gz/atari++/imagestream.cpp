/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: imagestream.cpp,v 1.3 2015/05/21 18:52:40 thor Exp $
 **
 ** In this module: Abstract base class for disk image source streams
 **********************************************************************************/
