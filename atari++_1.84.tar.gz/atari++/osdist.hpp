/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: osdist.hpp,v 1.3 2015/05/21 18:52:41 thor Exp $
 **
 ** In this module: The built-in Os ROM.
 **********************************************************************************/

#ifndef OSDIST_HPP
#define OSDIST_HPP

/// Exports
extern const unsigned char osdist[];
///

///
#endif
