/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: serialdevice.cpp,v 1.3 2015/05/21 18:52:42 thor Exp $
 **
 ** In this module: Interface specifications for serial devices.
 ** All serial devices (printer, disks, ...) must be derived from
 ** this class
 **********************************************************************************/

