/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: adrspace.cpp,v 1.3 2015/05/21 18:52:35 thor Exp $
 **
 ** In this module: Definition of the complete 64K address space of the emulator
 **********************************************************************************/
