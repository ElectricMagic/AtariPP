/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: basdist.hpp,v 1.1 2015/09/13 14:30:30 thor Exp $
 **
 ** In this module: The built-in Basic ROM.
 **********************************************************************************/

#ifndef BASDIST_HPP
#define BASDIST_HPP

/// Exports
extern const unsigned char basdist[];
///

///
#endif
