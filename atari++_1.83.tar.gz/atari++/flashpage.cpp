/***********************************************************************************
 **
 ** Atari++ emulator (c) 2002 THOR-Software, Thomas Richter
 **
 ** $Id: flashpage.cpp,v 1.3 2015/05/21 18:52:39 thor Exp $
 **
 ** In this module: Definition of a page of an AMD FlashROM
 **********************************************************************************/
